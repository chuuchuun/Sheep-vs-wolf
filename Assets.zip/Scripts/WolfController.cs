using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WolfController : PlayerController
{
    private List<Collider2D> lairs;
    private Collider2D isCarrying;
    protected bool isSleepy;
    protected bool isSleeping;

    override public void OnAwake()
    {
        lairs = new List<Collider2D>();
        RegisterLairs();
        isCarrying = null;
        isSleepy = false;
    }
    override protected void SetAnimation(Vector2 moveDirection)
    {
        if (Mathf.Abs(moveDirection.x) > Mathf.Abs(moveDirection.y))
        {
            // The sheep is moving more horizontally
            if (moveDirection.x > 0)
            {
                animator.SetBool("isFacingRight", true);
                animator.SetBool("isFacingUp", false);
                animator.SetBool("isFacingLeft", false);
                animator.SetBool("isFacingDown", false);
            }
            else
            {
                animator.SetBool("isFacingRight", false);
                animator.SetBool("isFacingUp", false);
                animator.SetBool("isFacingLeft", true);
                animator.SetBool("isFacingDown", false);
            }
        }
        else
        {
            if (moveDirection.y > 0)
            {
                animator.SetBool("isFacingRight", false);
                animator.SetBool("isFacingUp", true);
                animator.SetBool("isFacingLeft", false);
                animator.SetBool("isFacingDown", false);
            }
            else
            {
                animator.SetBool("isFacingRight", false);
                animator.SetBool("isFacingUp", false);
                animator.SetBool("isFacingLeft", false);
                animator.SetBool("isFacingDown", true);
            }
        }
    }
    protected override bool ProcessCollision(Collider2D other, ref Vector2 moveDirection)
    {
        if (other.CompareTag("sheep") && !IsCarrying() && !((SheepController)GetObject(other, 0)).IsCaptured() && !isSleepy)
        {
            moveDirection = FindRelativePath(other, true);
            return true;
        }
       // Choose a new direction if the collision is not with a sheep
            return false;
        
    }

    //CollisionTriggered
    protected void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("tree") && !IsCarrying() && !isSleepy)
        {
            ChooseNewDirection();
        }
        else if (other.CompareTag("sheep"))
        {

        }
        else if (other.CompareTag("lair"))
        {
            //Debug.Log("Lair is there!");
            if (IsCarrying())
            {
                moveSpeed = 0;
                isSleepy = true;
                ((LairController)GetObject(other, 2)).StartDevouring((Collider2D)GetComponent("Collider2D"));
            }
            else if (isSleepy && ((LairController)other.gameObject.GetComponent("LairController")).IsFree())
                SleepProcedure(other);
        }
    }
    private void RegisterLairs()
    {
        Collider2D[] hitColliders = Physics2D.OverlapCircleAll(transform.position, 100.0f); // Adjust radius as needed
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.CompareTag("lair") && !lairs.Contains(hitCollider))
            {
                //Debug.Log("Registered lair at " + hitCollider.transform.position.x + " " + hitCollider.transform.position.y);
                lairs.Add(hitCollider);
            }
        }
    }

    public override void Update()
    {

        Vector2 before = GetMoveDirection();
        base.Update(); // Call the parent class's Update method first
        if ((isSleepy || isCarrying))
            ChooseNewDirection();
        
    }

    protected void ChooseNewDirection()
    {
        if (!IsCarrying() && !isSleepy)
        {
            //Debug.Log(isSleepy);
            base.ChooseNewDirection();

            //Debug.Log("Case");
        }
        else
        {
            Collider2D toGo = FindNearestObject(lairs);
            SetMovementVector(FindRelativePath(toGo, true));
            Debug.Log("" + toGo.gameObject + " " + ((LairController)toGo.gameObject.GetComponent("LairController")).IsFree());
        }
    }

    public bool IsCarrying()
    {
        return isCarrying != null;
    }

    public Collider2D GetPrey()
    {
        return isCarrying;
    }

    public void GotPrey(SheepController prey)
    {
        isCarrying = (Collider2D)prey.gameObject.GetComponent("Collider2D");
        moveSpeed -= 0.5f;
        Collider2D toGo = FindNearestObject(lairs);
        
        SetMovementVector(FindRelativePath(toGo, true));
    }
    public void PreyBroke()
    {
        moveSpeed = 0;
        StartCoroutine(GoToNextTask(5));
    }
    protected IEnumerator GoToNextTask(float delay)
    {
        yield return base.GoToNextTask(delay);
        isCarrying = null;
        isSleeping = false;
        ChooseNewDirection();
    }
    public void RenewHunt()
    {
        StartCoroutine(GoToNextTask(1));
        //Debug.Log(isSleepy);
    }
    public bool IsSleeping()
    {
        return isSleeping;
    }
    public bool IsExhausted()
    {
        return isSleepy;
    }
    protected void SleepProcedure(Collider2D lair)
    {
        Debug.Log("F*ck this, I am going to sleep!");
        moveSpeed = 0;
        this.transform.position = lair.transform.position;
        isSleeping = true;
        StartCoroutine(GoToNextTask(8));
        isSleepy = false;
    }
}
