using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;

public class LairController : MonoBehaviour
{

    private Collider2D captured = null;

    void Start()
    {

    }

    public void StartDevouring(Collider2D other)
    {
        //Debug.Log("Collision");
        if (other.CompareTag("wolf")) {
            //Debug.Log("Wolf");
            WolfController w = (WolfController)other.gameObject.GetComponent("WolfController");
            if (captured == null && w.GetPrey() != null)
            {
                captured = w.GetPrey();
                SheepController sh = (SheepController)captured.gameObject.GetComponent("SheepController");
                sh.transform.SetParent(null);
                //sh.gameObject.GetComponent<Rigidbody2D>().simulated = true;
                sh.LairEvent();
                sh.transform.position = this.transform.position;
                w.RenewHunt();
                Debug.Log("" + gameObject + " " + IsFree() + " yeah!");
            }
        }
    }

    protected void OnTriggerEnter2D(Collider2D other)
    {

        if (other.CompareTag("sheep") && captured != null)
        {
            Debug.Log(captured);    
            SheepController anoth = (SheepController)other.gameObject.GetComponent("SheepController");
            if (!anoth.IsDying() && captured != null)
                anoth.SaveOperation(captured);
        }
            
    
    }
    public bool IsFree()
    {
        return captured == null;
    }


    public void FreeIfMe(Collider2D who)
    {
        if (!IsFree() && who.transform.position == captured.transform.position)
        {
            //Debug.Log("Freed!");
            captured = null;
        }
    }

}
